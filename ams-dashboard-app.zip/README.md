
# AMS Dashboard App

Projeto dividido em:

- **/frontend**: Aplicativo React para gerenciar visitas
- **/backend**: Servidor Express.js para salvar e listar visitas

## Deploy
- Frontend: Subir como Static Site (Vercel/Render)
- Backend: Subir como Web Service (Render)
