
const express = require('express');
const fs = require('fs');
const cors = require('cors');
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

const VISITS_FILE = './visits.json';

const loadVisits = () => {
  if (fs.existsSync(VISITS_FILE)) {
    const data = fs.readFileSync(VISITS_FILE);
    return JSON.parse(data);
  }
  return [];
};

const saveVisits = (visits) => {
  fs.writeFileSync(VISITS_FILE, JSON.stringify(visits, null, 2));
};

app.get('/visits', (req, res) => {
  const visits = loadVisits();
  res.json(visits);
});

app.post('/visits', (req, res) => {
  const { visit } = req.body;
  if (!visit) {
    return res.status(400).json({ error: 'Visit description is required.' });
  }
  const visits = loadVisits();
  visits.push({ id: Date.now(), visit });
  saveVisits(visits);
  res.status(201).json({ message: 'Visit added successfully.' });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
